package com.mashosoft.i18demo.interfaces.web.adapter;

import com.mashosoft.i18demo.application.ProductService;
import com.mashosoft.i18demo.domain.entity.Product;
import com.mashosoft.i18demo.interfaces.web.adapter.mapper.ProductDtoMapper;
import com.mashosoft.i18demo.interfaces.web.adapter.translator.DtoLiteralsFiller;
import com.mashosoft.i18demo.interfaces.web.dto.ProductDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
public class ProductInterfaceAdapter {

    private final ProductService productService;
    private final ProductDtoMapper productDtoMapper;
    private final DtoLiteralsFiller dtoLiteralsFiller;

    public ProductDTO getProductById(String id){
        Product product = productService.getProductById( id );
        ProductDTO productDTO = productDtoMapper.fromDomainToDTO( product );
        dtoLiteralsFiller.addDescriptions( productDTO );
        return productDTO;
    }
}
