package com.mashosoft.i18demo.domain.repository;

import com.mashosoft.i18demo.domain.entity.Product;

public interface ProductRepository {

    Product getProductFromDatabaseById(String id);
}
