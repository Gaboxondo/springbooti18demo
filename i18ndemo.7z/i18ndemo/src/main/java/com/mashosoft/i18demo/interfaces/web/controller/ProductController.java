package com.mashosoft.i18demo.interfaces.web.controller;

import com.mashosoft.i18demo.interfaces.web.adapter.ProductInterfaceAdapter;
import com.mashosoft.i18demo.interfaces.web.dto.ProductDTO;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@AllArgsConstructor
@RestController
@RequestMapping(value = "/product")
public class ProductController {

    private final ProductInterfaceAdapter productInterfaceAdapter;

    @RequestMapping(
        value = "v1/{id}",
        produces = MediaType.APPLICATION_JSON_VALUE,
        method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public ProductDTO getProductById(@PathVariable("id") String productId) {
        return productInterfaceAdapter.getProductById( productId );
    }
}
