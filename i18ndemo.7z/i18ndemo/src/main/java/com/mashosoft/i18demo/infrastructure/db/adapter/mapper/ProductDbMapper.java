package com.mashosoft.i18demo.infrastructure.db.adapter.mapper;

import com.mashosoft.i18demo.domain.entity.Product;
import com.mashosoft.i18demo.infrastructure.db.entity.ProductSQL;
import org.springframework.stereotype.Component;

@Component
public class ProductDbMapper {

    public Product fromDbToDomain(ProductSQL productSQL){
        if(productSQL == null){
            return null;
        }
        return new Product(productSQL.getId(), productSQL.getCode(), productSQL.getBrand(), productSQL.getCost() );
    }
}
