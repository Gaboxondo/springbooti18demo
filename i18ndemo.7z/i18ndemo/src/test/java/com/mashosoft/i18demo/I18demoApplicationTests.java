package com.mashosoft.i18demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class I18demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
