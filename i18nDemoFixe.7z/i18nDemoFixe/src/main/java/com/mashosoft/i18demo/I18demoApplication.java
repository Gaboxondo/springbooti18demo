package com.mashosoft.i18demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class I18demoApplication {

	public static void main(String[] args) {
		SpringApplication.run(I18demoApplication.class, args);
	}

}
