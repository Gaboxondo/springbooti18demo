package com.mashosoft.i18demo.config.exceptionHandling.model;

public interface BaseErrorCode {

    String getCode();
}
